## Player decomposition check

/** club_team_id, game_year -> league_name, club_logo_url, club_flag_url **/
SELECT COUNT(*)
FROM player
GROUP BY club_team_id, game_year
HAVING COUNT(DISTINCT(club_name)) > 1
       OR COUNT(DISTINCT(club_logo_url)) > 1
       OR COUNT(DISTINCT(club_flag_url)) > 1;

/** club_team_id -> club_name **/
SELECT COUNT(*)
FROM player
GROUP BY club_team_id
HAVING COUNT(DISTINCT(club_name)) > 1;

/** league_name -> league_level **/
SELECT COUNT(*)
FROM player
GROUP BY league_name
HAVING COUNT(DISTINCT(league_level)) > 1;

/** nationality_id -> nationality_name **/
SELECT COUNT(*), nationality_name
FROM player
GROUP BY nationality_id
HAVING COUNT(DISTINCT(nationality_name)) > 1;



